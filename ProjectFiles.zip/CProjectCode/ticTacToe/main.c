#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <conio.h>
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>

// sets the initial values for various global game variables
bool hasWon = false;
bool firstPlay = true;
bool singlePlayer;
int turnCount = 0;
int winner;
int xWins = 0;
int oWins = 0;

// two dimensional char array for the game board. All spaces are blank initially.
char board[8][7] = 
{
	{" 1 2 3"},
	{"1 | | "},
	{" -----"},
	{"2 | | "},
	{" -----"},
	{"3 | | "}
};

// function that handles printing the welcome message onto the screen and  
// prompting the user to input what type of game they wish to play.
void displayWelcomeScreen()
{
	printf("\n\n\n\n\n\n\n\n\t\t\t  Welcome to Tic-Tac-Toe");
	printf("\n\tProgrammed by Grant Abella, Alex Jaeger, and Ethan Horvath");
	_getch();
	bool d = false;
	while (d == false)
	{
		system("cls");
		printf("1. Single player against the computer.\n");
		printf("2. Two player against another human.\n");
		printf("Select the type of game you would like to play: ");
		int c;
		scanf("%d", &c);
		if (c == 1)
		{
			singlePlayer = true;
			d = true;
		}
		if (c == 2)
		{
			singlePlayer = false;
			d = true;
		}
	}
	firstPlay = false;
	system("cls");
}

// function that handles printing the board onto the screen.
void displayBoard()
{
	// clear the screen
	system("cls");
	// print the player win counts on the screen
	printf("X wins: %d\n", xWins);
	printf("O wins: %d\n\n\n", oWins);
	// print the board character array
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			printf("%c", board[i][j]);
		}
		printf("\n");
	}
}

// function that takes the coordinates that the player inputs and 
// converts them to the cooresponding indices of the board array.
void handleMarks(int x, int y)
{
	int actualX, actualY;
	// set the actual value for the x coordinate 
	switch (x) 
	{
		case 1:
			actualX = 1;
			break;
		case 2:
			actualX = 3;
			break;
		case 3:
			actualX = 5;
			break;
		default:
			actualX = NULL;
			break;
	} 
	// set the actual value for the y coordinate 
	switch (y)
	{
		case 1:
			actualY = 1;
			break;
		case 2:
			actualY = 3;
			break;
		case 3:
			actualY = 5;
			break;
		default:
			actualY = NULL;
			break;
	}

	if (actualX && actualY != NULL)
	{
		if (board[actualY][actualX] == ' ') // if space on the board is empty
		{
			turnCount++; // increment turnCount by one
			if (turnCount % 2 == 0) // even turns mean 'O' is placed on board
			{
				board[actualY][actualX] = 'O';
			}
			if (turnCount % 2 == 1) // odd turns mean 'X' is placed on board
			{
				board[actualY][actualX] = 'X';
			}
		}
		else
			return;
	}
}

// function that checks for three concecutive X's or O's in a row, 
// column, or diagonal.
int checkForWin()
{
	// set x and o counters to zero
	int countX = 0;
	int countO = 0;
	int countSpaces = 0;
	// check rows
	for (int i = 1; i < 7; i += 2)
	{
		for (int j = 1; j < 7; j += 2)
		{
			if (board[i][j] == 'X')
			{
				countX++;
				// return -1 if three X's are found in a row and set hasWon boolean to true
				if (countX == 3)
				{
					hasWon = true;
					return(-1);
				}
			}
			if (board[i][j] == 'O')
			{
				countO++;
				// return 1 if three O's are found in a row and set hasWon boolean to true
				if (countO == 3)
				{
					hasWon = true;
					return(1);
				}
			}
			// condition that checks for number of open spaces left on the board
			if (board[i][j] == ' ')
			{
				countSpaces++;
			}
		}
		// resets X and O counters
		countX = 0;
		countO = 0;
	}
	// return 0 if there are no more open spaces on the board and nobody has won yet
	// this signifies a draw, and the game is ended.
	if (countSpaces == 0)
	{
		hasWon = true;
		return(0);
	}
	// reset the x and o counters
	countX = 0;
	countO = 0;
	// check columns
	for (int j = 1; j < 7; j += 2)
	{
		for (int i = 1; i < 7; i += 2)
		{
			if (board[i][j] == 'X')
			{
				countX++;
				// return -1 if three X's are found in a column and set hasWon boolean to true
				if (countX == 3)
				{
					hasWon = true;
					return(-1);
				}
			}
			if (board[i][j] == 'O')
			{
				countO++;
				// return 1 if three O's are found in a column and set hasWon boolean to true
				if (countO == 3)
				{
					hasWon = true;
					return(1);
				}
			}
		}
		// reset the x and o counters
		countX = 0;
		countO = 0;
	}
	// reset the x and o counters
	countX = 0;
	countO = 0;
	// check diagonals (1,1), (3,3), and (5,5)
	for (int i = 1; i < 7; i += 2)
	{
		if (board[i][i] == 'X')
		{
			countX++;
			if (countX == 3)
			{
				hasWon = true;
				return(-1);
			}
		}
		if (board[i][i] == 'O')
		{
			countO++;
			if (countO == 3)
			{
				hasWon = true;
				return(1);
			}
		}
	}
	// reset the x and o counters
	countX = 0;
	countO = 0;
	// check diagonals (1,5), (3,3), and (1,5)
	for (int i = 5; i > 0; i -= 2)
	{
		if (board[i][6 - i] == 'X')
		{
			countX++;
			if (countX == 3)
			{
				hasWon = true;
				return(-1);
			}
		}
		if (board[i][6 - i] == 'O')
		{
			countO++;
			if (countO == 3)
			{
				hasWon = true;
				return(1);
			}
		}
	}
	// reset the x and o counters
	countX = 0;
	countO = 0;
}

// function that fills the board with open spaces
void resetBoard()
{
	// fills the board with open spaces
	for (int i = 1; i < 7; i += 2)
	{
		for (int j = 1; j < 7; j += 2)
		{
			board[i][j] = ' ';
		}
	}
}

// function called after a game is finished. If the user wishes to play another
// game, the global variables are reset and the board is cleared. If not, the program
// continues to the end of main().
void playAgain()
{
	char ch;
	scanf("%c", &ch);
	if (ch == 'y' || ch == 'Y')
	{
		// reset global variables and start from the begining of main() again
		turnCount = 0;
		hasWon = false;
		resetBoard();
		main();
	}
	else if (ch == 'n' || ch == 'N')
	{
		// continue to the end of main
		printf("Thanks for playing!");
	}
	else
	{
		playAgain();
	}
}

void playerTwo()
{
	// returns to main if there are no more open spaces left on the board.
	if (checkForWin() == 0)
		return;
	// generate values between 1 and 3 for the x and y coordinates that the computer will mark.
	int x = rand() % 3 + 1;
	int y = rand() % 3 + 1;
	// adjust the randomly generated x coordinate to the actual coordinate on the board.
	switch (x)
	{
	case 1:
		x = 1;
		break;
	case 2:
		x = 3;
		break;
	case 3:
		x = 5;
		break;
	}
	// adjust the randomly generated y coordinate to the actual coordinate on the board.
	switch (y)
	{
	case 1:
		y = 1;
		break;
	case 2:
		y = 3;
		break;
	case 3:
		y = 5;
		break;
	}

	// if the random space on the board is open, place an 'O' and increase the turn counter.
	if (board[y][x] == ' ')
	{
		board[y][x] = 'O';
		turnCount++;
		return;
	}
	// if not, start from the begining of the function and try again.
	playerTwo();
}

int main(void)
{
	// seeds the random with time so that numbers generated in playerTwo() are truly random
	srand((unsigned)time(0));
	// display the welcome screen if this is the first time the user has played
	if (firstPlay == true)
	{
		displayWelcomeScreen();
	}
	// display the game board right away
	displayBoard();
	// main game loop. Runs until the hasWon boolean is true
	while (!hasWon)
	{
		// prints on screen whose turn it currently is
		if (turnCount %2 == 0)
			printf("Turn: X\n");
		if (turnCount % 2 == 1)
			printf("Turn: O\n");
		// if the game is in two player mode or if it is in one player mode and it is player one's turn
		if (!singlePlayer || (singlePlayer && turnCount % 2 == 0))
		{
			// promp the user for the x coordinate that they wish to mark
			printf("X coordinate: ");
			int xCoord;
			scanf("%d", &xCoord);
			// promp the user for the y coordinate that they wish to mark
			printf("Y coordinate: ");
			int yCoord;
			scanf("%d", &yCoord);
			// sends xCoord and YCoord to the function that converts them to actual board coordinates
			handleMarks(xCoord, yCoord);
		}
		// call the playerTwo function if in single player mode and it is the computer's turn
		if (singlePlayer && turnCount % 2 == 1)
			playerTwo();
		// calls the function to print the board onto the screen
		displayBoard();
		// checks for a winner and stores the result in winner integer
		winner = checkForWin();
	}
	// check the condition of the winner variable
	switch (winner)
	{
		// if the winner integer equals 0, the game is a draw
		case 0:
			printf("The game is a draw!");
			break;
		// if the winner integer equals -1, X has won the game
		case -1:
			xWins++;
			displayBoard();
			printf("X has won the game!");
			break;
		// if the winner integer equals 1, O has won the game
		case 1:
			oWins++;
			displayBoard();
			printf("O has won the game!");
			break;
	}
	// ask user if they wish to play another game
	printf("\nWould you like to play another game of Tic-Tac-Toe (Y/N)?");
	playAgain();
	_getch();
	return(0);
}