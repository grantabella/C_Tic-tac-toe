import os     #used to clear the screen
import sys    #used to print the board properly
import random #used to randomly select coordinates for the computer
turnCount = 0
xWins = 0
oWins = 0
firstPlay = True
singlePlayer = True
#game board
board = [[" ","1"," ","2"," ","3"],
         ["1"," ","|"," ","|"," "], 
         [" ","-","-","-","-","-"],
         ["2"," ","|"," ","|"," "],
         [" ","-","-","-","-","-"],
         ["3"," ","|"," ","|"," "]]
#function to print the board and display
def disp():
    global turnCount, xWins, oWins
    print("X wins: " + repr(xWins))
    print("O wins: " + repr(oWins))
    print("")
    for i in range(0,6):
        for j in range(0,6):
            #we must use this instead of print() or else it 
            #goes to the next line after each space is printed
            sys.stdout.write(board[i][j])
        sys.stdout.write("\n")
    #print the current player's turn on the screen
    if(turnCount % 2 == 0):
        print("Turn: X")
    else:
        print("Turn: O")
    return
#function to adjust the values input by the user to real coordinates
def adjustValue(a):
    if(a == 1):
        return 1
    if(a == 2):
        return 3
    if(a == 3):
        return 5
    return
#function that handles getting input from the user
def getInput():
    global turnCount, singlePlayer
    #if the game is single player, call the playerTwo function if it is player two's turn
    if(singlePlayer == True and turnCount % 2 == 1):
        playerTwo()
        return
    try:
        x = int(input("X coordinate: "))
    #if the user does not input an integer
    except ValueError:
        os.system("cls")
        disp()
        getInput()
    if(x > 3 or x < 1):
        return
    try:
        y = int(input("Y coordinate: "))
    #if the user does not input an integer
    except ValueError:
        os.system("cls")
        disp()
        getInput() 
    if(y > 3 or y < 1):
        return
    x = adjustValue(x)
    y = adjustValue(y)
    #if the chosen space is free, mark it with an X or an O
    if(board[y][x] == ' '):
        if(turnCount % 2 == 0):
            board[y][x] = 'X'
        else:
            board[y][x] = 'O'
        turnCount += 1
    return
#function that handles the computer player in single player mod
def playerTwo():
    global turnCount
    #generate two random coordinates to place the computer's mark
    x = random.randint(1, 3)
    y = random.randint(1, 3)
    #adjust the generated coordinates to the appropriate coordinates in the board list
    x = adjustValue(x)
    y = adjustValue(y)
    #place the computer's mark if the chosen space is free
    if(board[y][x] == ' '):
        board[y][x] = 'O'
        turnCount += 1
        return
    #loop back to the beginning of this function if the space is not free
    else:
        playerTwo()
    return
#function that checks for 3 of the same marks in a row, column or diagonally
#this function also checks for a draw
def checkForWin():
    count = 0
    #range is:
        #1: the initial value for the integer
        #7: the value the range can not pass
        #2: the value the integer increases (1, 3, 5)
    #check rows for X
    for j in range(1,7,2):
        for i in range(1,7,2):
            if(board[j][i] == 'X'):
                count += 1
        if(count == 3):
            handleWin('X')
        count = 0
    #check rows for O
    for j in range(1,7,2):
        for i in range(1,7,2):
            if(board[j][i] == 'O'):
                count += 1
        if(count == 3):
            handleWin('O')
        count = 0
    #check columns for X
    for j in range(1,7,2):
        if(board[j][1] == 'X'):
            count += 1
    if(count == 3):
        handleWin('X')
    count = 0
    for j in range(1,7,2):
        if(board[j][3] == 'X'):
            count += 1
    if(count == 3):
        handleWin('X')
    count = 0
    for j in range(1,7,2):
        if(board[j][5] == 'X'):
            count += 1
    if(count == 3):
        handleWin('X')
    count = 0
    #check columns for O
    for j in range(1,7,2):
        if(board[j][1] == 'O'):
            count += 1
    if(count == 3):
        handleWin('O')
    count = 0
    for j in range(1,7,2):
        if(board[j][3] == 'O'):
            count += 1
    if(count == 3):
        handleWin('O')
    count = 0
    for j in range(1,7,2):
        if(board[j][5] == 'O'):
            count += 1
    if(count == 3):
        handleWin('O')
    count = 0
    #check diagonals for X
    for j in range(1,7,2):
        if(board[j][j] == 'X'):
            count += 1
    if(count == 3):
        handleWin('X')
    count = 0   
    if(board[1][5] == 'X'):
        if(board[3][3] == 'X'):
            if(board[5][1] == 'X'):
                handleWin('X')
    count = 0 
    #check diagonals for O
    for j in range(1,7,2):
        if(board[j][j] == 'O'):
            count += 1
    if(count == 3):
        handleWin('O')
    count = 0   
    if(board[1][5] == 'O'):
        if(board[3][3] == 'O'):
            if(board[5][1] == 'O'):
                handleWin('O')
    count = 0
    #check for draw
    for j in range(1,7,2):
        for i in range(1,7,2):
            if(board[j][i] == 'X' or board[j][i] == 'O'):
                count += 1
    if(count == 9):
        handleWin('D')
    count = 0
    return
#function that handles what happens after a player has won or if the game is a draw
#takes 1 argument:
    #X = X has won the game
    #O = O has won the game
    #D = The game is a draw
def handleWin(a):
    os.system("cls")
    disp()
    global xWins, oWins
    if(a == 'X'):
        xWins += 1
        print("X has won the game!")
    if(a == 'O'):
        oWins += 1
        print("O has won the game!")
    if(a == 'D'):
        print("The game is a draw!")
    ch = input("Would you like to play another game of Tic-Tac-Toe (Y/N)?")
    #calls the resetGame function if the player wishes to play another game
    if(ch == "y" or ch == "Y"):
        resetGame()
    #exits the game if the player does not wish to play another game
    else:
        input("Thanks for playing!")
        sys.exit()
    return
#function that resets the game if the player wishes to play again
def resetGame():
    global turnCount
    #resets the turnCount variable to 0
    turnCount = 0
    #fills the game board with free spaces
    for j in range(1,7,2):
        for i in range(1,7,2):
            board[j][i] = ' '
    return
    
    
#main game loop
while(1):
    #if it is the player's first time playing, display the welcome screen and ask
    #which game mode they would like to play
    if(firstPlay == True):
        print("\n\n\n\n\n\n\n\n\t\t\t  Welcome to Tic-Tac-Toe")
        print("\n\tProgrammed by Grant Abella, Alex Jaeger, and Ethan Horvath")
        input("\n\t\t\t   Press enter to play")
        firstPlay = False
        d = False
        while(d == False):
            os.system("cls")
            print("1. Single player against the computer.\n")
            print("2. Two player against another human.\n")
            ch = int(input("Select the type of game you would like to play: "))
            if(ch == 1):
                singlePlayer = True
                d = True
            if(ch == 2):
                singlePlayer = False
                d = True
        os.system("cls")
    disp()
    getInput()
    checkForWin()
    os.system("cls")